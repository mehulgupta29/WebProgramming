var exports = module.exports = {};

// You can now add export properties to the exports object to be accessible from outside this file
