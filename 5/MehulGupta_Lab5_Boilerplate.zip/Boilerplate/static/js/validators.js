// Remember, we're in a browser: prevent global variables from happening
// I am passing the jQuery variable into the IIFE so that
// I don't have to rely on global variable name changes in the future

(function ($) {

    var errorAlert = $("#error-message");
    var resultAlert = $("#calculator-result");
    var bothAlerts = errorAlert.add(resultAlert);

    var yearsInput = $("#years");
    var savingAmountInput = $("#savingAmount");
    var roiInput = $("#roi");

    var submitSavingPerMonthButton = $("#submitSavingPerMonth");

    function extractInputs() {

    
        // check on years
        var yearsValue = yearsInput.val();
        if (yearsValue === undefined || yearsValue === "" || yearsValue === null) {
            throw "No Year value provided";
        }
        var yearsValue = parseInt(yearsValue);
        if (isNaN(yearsValue)) {
            throw "Year value is not a number";
        }
        if(yearsValue < 1 || yearsValue > Number.MAX_VALUE)
            throw "Year out of bound";

        
        // check on amount
        var amountValue = savingAmountInput.val();
        if (amountValue === undefined || amountValue === "" || amountValue === null) {
            throw "No Amount value provided";
        }
        var amountValue = parseInt(amountValue);       
        if (isNaN(amountValue)) {
            throw "Amount value is not a number";
        }
        if(amountValue < 1 || amountValue > Number.MAX_VALUE)
            throw "Savings Amount out of range";
        
        // check on ROI
        var rateValue = roiInput.val();
        if (rateValue === undefined || rateValue === "" || rateValue === null) {
            throw "No Rate Of Interest value provided";
        }
        var rateValue = parseFloat(rateValue);
        if (isNaN(rateValue)) {
            throw "Rate of Interest value is not a number";
        }
        if(rateValue < 0 || rateValue > 1)
            throw "Rate of Interest out of range";

        return true;
    }

    submitSavingPerMonthButton.click(function () {
        bothAlerts.addClass('hidden');
        bothAlerts.text('');

        try {
            var values = extractInputs();
            resultAlert.removeClass('hidden');
        } catch (error) {
            errorAlert.text(error);
            errorAlert.removeClass('hidden');
            return false; 
        }
    });


    // For 2nd Function
    var yearInput = $("#year");
    var initialAmountInput = $("#initialAmount");
    var rateInput = $("#rate");

    var submitInvestedAmountButton = $("#submitInvestedAmount");

    function submitInvestedAmountextractInputs() {

    
        // check on years
        var yearValue = yearInput.val();
        if (yearValue === undefined || yearValue === "" || yearValue === null) {
            throw "No Year value provided";
        }
        var yearValue = parseInt(yearValue);
        if (isNaN(yearValue)) {
            throw "Year value is not a number";
        }
        if(yearValue < 1 || yearValue > Number.MAX_VALUE)
            throw "Year out of bound";

        
        // check on amount
        var initialAmountValue = initialAmountInput.val();
        if (initialAmountValue === undefined || initialAmountValue === "" || initialAmountValue === null) {
            throw "No Amount value provided";
        }
        var initialAmountValue = parseInt(initialAmountValue);       
        if (isNaN(initialAmountValue)) {
            throw "Amount value is not a number";
        }
        if(initialAmountValue < 1 || initialAmountValue > Number.MAX_VALUE)
            throw "Initial Amount out of range";
        
        // check on ROI
        var roiValue = rateInput.val();
        if (roiValue === undefined || roiValue === "" || roiValue === null) {
            throw "No Rate Of Interest value provided";
        }
        var roiValue = parseFloat(roiValue);
        if (isNaN(roiValue)) {
            throw "Rate of Interest value is not a number";
        }
        if(roiValue < 0 || roiValue > 1)
            throw "Rate of Interest out of range";

        return true;
    }

    submitInvestedAmountButton.click(function () {
        bothAlerts.addClass('hidden');
        bothAlerts.text('');

        try {
            var values = submitInvestedAmountextractInputs();
            resultAlert.removeClass('hidden');
        } catch (error) {
            errorAlert.text(error);
            errorAlert.removeClass('hidden');
            return false; 
        }
    });

    // For 3rd Function
    var monthlyAmountInput = $("#monthlyAmount");
    var loanAmountInput = $("#loanAmount");
    var interestRateInput = $("#interestRate");

    var submitLoanPayoffButton = $("#submitLoanPayoff");

    function submitLoanPayoffextractInputs() {

    
        // check on monthly amount
        var monthlyAmountValue = monthlyAmountInput.val();
        if (monthlyAmountValue === undefined || monthlyAmountValue === "" || monthlyAmountValue === null) {
            throw "No Monthly Amount value provided";
        }
        var monthlyAmountValue = parseInt(monthlyAmountValue);
        if (isNaN(monthlyAmountValue)) {
            throw "Monthly Amount Value is not a number";
        }
        if(monthlyAmountValue < 1 || monthlyAmountValue > Number.MAX_VALUE)
            throw "Monthly Amount value out of bound";

        
        // check on Loan amount
        var loanAmountValue = loanAmountInput.val();
        if (loanAmountValue === undefined || loanAmountValue === "" || loanAmountValue === null) {
            throw "No Loan Amount value provided";
        }
        var loanAmountValue = parseInt(loanAmountValue);       
        if (isNaN(loanAmountValue)) {
            throw "Loan Amount value is not a number";
        }
        if(loanAmountValue < 1 || loanAmountValue > Number.MAX_VALUE)
            throw "Loan Amount out of range";
        
        // check on ROI
        var interestRateValue = interestRateInput.val();
        if (interestRateValue === undefined || interestRateValue === "" || interestRateValue === null) {
            throw "No Rate Of Interest value provided";
        }
        var interestRateValue = parseFloat(interestRateValue);
        if (isNaN(interestRateValue)) {
            throw "Rate of Interest value is not a number";
        }
        if(interestRateValue < 0 || interestRateValue > 1)
            throw "Rate of Interest out of range";

        return true;
    }

    submitLoanPayoffButton.click(function () {
        bothAlerts.addClass('hidden');
        bothAlerts.text('');

        try {
            var values = submitLoanPayoffextractInputs();
            resultAlert.removeClass('hidden');
        } catch (error) {
            errorAlert.text(error);
            errorAlert.removeClass('hidden');
            return false; 
        }
    });

})(jQuery);
// jQuery is exported as $ and jQuery