// We first require our express package
var express = require('express');
var bodyParser = require('body-parser');
var myData = require('./data.js');

// This package exports the function to create an express instance:
var app = express();

// We can setup Jade now!
app.set('view engine', 'ejs');

// This is called 'adding middleware', or things that will help parse your request
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// This middleware will activate for every request we make to 
// any path starting with /assets;
// it will check the 'static' folder for matching files 
app.use('/assets', express.static('static'));

// Setup your routes here!

app.get("/home", function (request, response) {
    response.render("pages/home", { pageTitle: "Welcome Home" });
});

app.get("/api/perMonthRetirementSavings", function(request, response){
	
	try{
		var years = request.query.years;
		var perMonth = request.query.perMonth;
		var interestRate = request.query.interestRate;

		var res = myData.retirementAmountIfSavingPerMonth(years, perMonth, interestRate);
			response.json(res);
	}catch(message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});

app.get("/api/investedAmount", function(request, response){
	try{
		var years = request.query.years;
		var initial = request.query.initial;
		var interestRate = request.query.interestRate;

		var res = myData.investedAmountAfterSomeYears(years, initial, interestRate);
			response.json(res);
	}catch(message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});

app.get("/api/loanPayoff", function(request, response){
	 try{
		var monthlyAmount = request.query.monthlyAmount;
		var loanAmount = request.query.loanAmount;
		var interestRate = request.query.interestRate;

		var res = myData.monthsToPayOffLoan(monthlyAmount, loanAmount, interestRate);
			response.json(res);
	}catch(message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});

app.post("/results/perMonthRetirementSavings", function (request, response) {
    try {
        var result = myData.retirementAmountIfSavingPerMonth(request.body.years, request.body.savingAmount, request.body.roi);
        response.render('pages/result', { result: result, pageTitle: result.operationTitle});
    } catch (message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});

app.post("/results/investedAmount", function (request, response) {
    try {
        var result = myData.investedAmountAfterSomeYears(request.body.year, request.body.initialAmount, request.body.rate);
        response.render('pages/result', { result: result, pageTitle: result.operationTitle});
    } catch (message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});


app.post("/results/loanPayoff", function (request, response) {
    try {
        var result = myData.monthsToPayOffLoan(request.body.monthlyAmount, request.body.loanAmount, request.body.interestRate);
        response.render('pages/result', { result: result, pageTitle: result.operationTitle});
    } catch (message) {
        // we caught an exception! Let's show an error page!
        response.status(500).render('pages/error', { errorType: "Issue creating result!", errorMessage: message });
    }
});

app.get("/", function (request, response) { 
    // We have to pass a second parameter to specify the root directory
    // __dirname is a global variable representing the file directory you are currently in
    //response.sendFile("./pages/index.html", { root: __dirname });
    response.render('pages/index');
});

// We can now navigate to localhost:3000
app.listen(3000, function () {
    console.log('Your server is now listening on port 3000! Navigate to http://localhost:3000 to access it');
});
